from setuptools import find_packages, setup

setup(
    name='netos',
    version='0.0.1',
    description='A plugin to enrich NetBox models',
    install_requires=[],
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
)
